import os

print(os.system('df -h'))
print(os.system('uptime'))
print(os.system('free -h'))
print(os.system('uname -a'))
print(os.system('ls -l'))
print(os.system('pwd'))
print(os.system('whoami'))