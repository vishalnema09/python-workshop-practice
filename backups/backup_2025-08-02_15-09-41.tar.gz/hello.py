name = input("Enter your name: ") # Get user input
name = "rahul" # name is set to "rahul"
print("Hello", name) # print the name that was set in last line
