num1 = int(input("enter first number: ")) 
num2 = int(input("enter second number: ")) 

sum = num1 + num2 
print("The sum is:", sum)

difference = num1 - num2 
print("The difference is:", difference) 

product = num1 * num2 
print("The product is:", product)

division = num1 / num2
print("The division is:", division)

